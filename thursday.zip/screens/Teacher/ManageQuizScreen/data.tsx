export const selectCourseOption = [
  { id: 0, name: "Cannabis 2023" },
  { id: 1, name: "Cannabis 2024" },
  { id: 2, name: "Cannabis 2025" },
  { id: 3, name: "Cannabis 2026" },
];
export const selectFolderOption = [
  { id: 0, name: "/ Daily" },
  { id: 1, name: "/ Daily 1" },
  { id: 2, name: "/ Daily 2" },
  { id: 3, name: "/ Daily 3" },
];
export const selectStatusOption = [
  { id: 0, name: "Completed" },
  { id: 1, name: "Draft" },
];