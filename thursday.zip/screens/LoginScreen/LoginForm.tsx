import React, { useCallback, useEffect, useState } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import {
  Box,
  CircularProgress,
  Divider,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  Link,
  OutlinedInput,
  TextField,
  Typography,
} from "@mui/material";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";

import { useFormik } from "formik";
import * as Yup from "yup";
import { useSnackbar } from "notistack";

import FormattedMessage, { useFormattedMessage } from "theme/FormattedMessage";

import messages from "./messages";
import { ButtonWrapper, LoadingButtonWrapper } from "./Styled";
import { useAuthContext } from "contexts/AuthContext";
import { useRouter } from "next/router";
import { TOKEN } from "configs";
import CloseIcon from "@mui/icons-material/Close";

const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label("Email"),
  password: Yup.string().required().label("Password"),
});

const LoginForm = () => {
  const router = useRouter();
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const { signIn } = useAuthContext();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const onSubmit = useCallback(async (data: any) => {
    if (!loading) {
      setLoading(true);
    }
    const resp: any = await signIn("credentials", {
      ...data,
      redirect: false,
    });
    try {
      setLoading(true);
      if (!resp?.ok) {
        setLoading(false);
        throw new Error("Request failed");
      }
      if (!resp.error) {
        setLoading(true);
        router.push("/dashboard");
        enqueueSnackbar(<FormattedMessage {...messages.successMessage} />, {
          variant: "success",
          action: (key) => (
            <IconButton onClick={() => closeSnackbar(key)} size="small">
              <CloseIcon sx={{ color: "#fff" }} />
            </IconButton>
          ),
        });
        // localStorage.setItem(TOKEN, resp?.data.token);
      }
    } catch (error: any) {
      if (resp.error) {
        const errorCode = error.code;
        const errorMessage = error.message;
        enqueueSnackbar("Invalid Email or Password", {
          variant: "error",
          action: (key) => (
            <IconButton onClick={() => closeSnackbar(key)} size="small">
              <CloseIcon sx={{ color: "#fff" }} />
            </IconButton>
          ),
        });
      }
    }
    // console.log(resp, "resp");
  }, []);

  // use formik
  const { handleChange, handleSubmit, handleBlur, errors, values, touched } =
    useFormik({
      initialValues: { email: "", password: "" },
      validationSchema,
      onSubmit,
    });

  // handleResetPass
  const handleResetPass = (email: string) => {};

  const userPlaceholder = useFormattedMessage(messages.userPlaceholder);
  const passwordPlaceholder = useFormattedMessage(messages.passwordPlaceholder);

  return (
    <form onSubmit={handleSubmit}>
      <Grid container direction={"column"} spacing={3}>
        <Grid item>
          <InputLabel
            sx={{ color: (theme) => theme.palette.text.primary }}
            htmlFor="password"
          >
            <FormattedMessage {...messages.userLabel} />
          </InputLabel>
          <TextField
            id="email"
            name="email"
            type="text"
            value={values.email}
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder={userPlaceholder}
            error={touched.email && Boolean(errors.email)}
            helperText={touched.email && errors.email}
            autoComplete="off"
            variant="standard"
            fullWidth
          />
        </Grid>

        <Grid item>
          <InputLabel
            sx={{ color: (theme) => theme.palette.text.primary }}
            htmlFor="password"
          >
            <FormattedMessage {...messages.passwordLabel} />
          </InputLabel>
          <Box display={"flex"} flexDirection={"column"} position={"relative"}>
            <TextField
              id="password"
              name="password"
              value={values.password}
              onChange={handleChange}
              onBlur={handleBlur}
              type={showPassword ? "text" : "password"}
              placeholder={passwordPlaceholder}
              error={touched.password && Boolean(errors.password)}
              autoComplete="off"
              variant="standard"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              fullWidth
            />
            {touched.password && errors.password && (
              <FormHelperText error id="standard-weight-helper-text-password">
                {errors.password}
              </FormHelperText>
            )}
          </Box>
        </Grid>
      </Grid>

      <Box
        sx={{
          display: "flex",
          justifyContent: "end",
          margin: "20px 0",
        }}
      >
        <Link
          href="/forgot"
          underline="none"
          color="#8C2531"
          sx={{ textDecoration: "underline" }}
        >
          <FormattedMessage {...messages.forgot} />
        </Link>
      </Box>
      <Box sx={{ mb: 3 }}></Box>
      <Box>
        <LoadingButtonWrapper
          disabled={(values.email && values.password) === "" || loading}
          type="submit"
          variant="contained"
          // loading={loading}
          loadingPosition="start"
          sx={{
            ".MuiLoadingButton-loadingIndicator": {
              top: "35%",
              left: "35%",
            },
          }}
        >
          <FormattedMessage {...messages.logIn} />
          {loading && (
            <CircularProgress
              size={20}
              sx={{
                color: theme => theme.palette.primary.light,
                position: 'absolute',
                top: '50%',
                left: '50%',
                marginTop: '-10px',
                marginLeft: '30px',
              }}
            />
          )} 
          
        </LoadingButtonWrapper>
        <Divider
          sx={{
            marginY: "20px",
            color: (theme) => theme.palette.secondary.dark,
          }}
        >
          <FormattedMessage {...messages.OR} />
        </Divider>
        <ButtonWrapper
          onClick={(e) => {
            e.preventDefault;
            // router.push("/register");
          }}
          sx={{
            color: (theme) => theme.palette.primary.main,
            background: "none",
            boxShadow: "none",
            border: "1px solid #EAEAEA",
            "&:hover": {
              color: (theme) => theme.palette.primary.light,
            },
          }}
          variant="contained"
        >
          <FormattedMessage {...messages.SSO} />
        </ButtonWrapper>
      </Box>

      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          marginY: "10px",
        }}
      >
        <FormattedMessage {...messages.textSignUp} />
      </Box>
      <ButtonWrapper
        onClick={(e) => {
          e.preventDefault;
          router.push("/register");
        }}
        sx={{
          color: (theme) => theme.palette.primary.main,
          background: "none",
          boxShadow: "none",
          border: "1px solid #EAEAEA",
          "&:hover": {
            color: (theme) => theme.palette.primary.light,
          },
        }}
        variant="contained"
      >
        <FormattedMessage {...messages.signUp} />
      </ButtonWrapper>
    </form>
  );
};

export default LoginForm;
