export const genderSelect = [
  { id: 0, name: "Select from the list" },
  { id: 1, name: "Male" },
  { id: 2, name: "Female" },
  { id: 3, name: "Prefer Not to Say" },
];

export const programSelect = [
  { id: 0, name: "Select from the list" },
  { id: 1, name: "COP" },
  { id: 2, name: "POD" },
];

export const mathSkillsSelect = [
  { id: 1, name: "Select an option for the list" },
  { id: 2, name: "Basic" },
  { id: 3, name: "Average" },
  { id: 4, name: "Experienced" },
];
export const radioChoice = [
  { id: 1, name: "Yes" },
  { id: 2, name: "No" },
];

export const learnRadioGroup = [
  { id: 1, name: "Facts" },
  { id: 2, name: "Relationships" },
];

export const sequenceRadioGroup = [
  { id: 1, name: "In order" },
  { id: 2, name: "Big Picture First" },
];

export const studyRadioGroup = [
  { id: 1, name: "By My Self" },
  { id: 2, name: "In Groups" },
];

export const playRadioGroup = [
  { id: 1, name: "a variety of sport" },
  { id: 2, name: "an instrument" },
  { id: 3, name: "in a play" },
  { id: 4, name: "in a pep squad" },
  { id: 5, name: "at a student government" },
];
